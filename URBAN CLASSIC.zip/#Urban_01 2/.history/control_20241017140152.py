import cv2
import numpy as np
import time
import linesdetect

red_point = False
end_crossroad = False 
yellow = False
yellow_on = False

def detect_lines(image):
        
    rho = 1  
    angle = np.pi / 180  
    min_threshold = 10  
    lines = cv2.HoughLinesP(image, rho, angle, min_threshold, np.array([]), minLineLength=8, maxLineGap=4)
                
    return lines


def find_lines(frame, lines):
    a = np.zeros_like(frame)
    try:
        left_line_x = []
        left_line_y = []
        right_line_x = []
        right_line_y = []
        for line in lines:
            for x1, y1, x2, y2 in line:
                slope = (y2 - y1) / (x2 - x1) 
                if abs(slope) < 0.5: 
                    continue
                if slope <= 0:
                    left_line_x.extend([x1, x2])
                    left_line_y.extend([y1, y2])
                else: 
                    right_line_x.extend([x1, x2])
                    right_line_y.extend([y1, y2])
        min_y = int(frame.shape[0] * (3 / 5)) 
        max_y = int(frame.shape[0]) 
        poly_left = np.poly1d(np.polyfit(left_line_y, left_line_x, deg=1))
        left_x_start = int(poly_left(max_y))
        left_x_end = int(poly_left(min_y))
        poly_right = np.poly1d(np.polyfit( right_line_y, right_line_x, deg=1))
        right_x_start = int(poly_right(max_y))
        right_x_end = int(poly_right(min_y))
        cv2.line(a, (left_x_start, max_y), (left_x_end, min_y), [255,0,0], 5)
        cv2.line(a, (right_x_start, max_y), (right_x_end, min_y), [255,0,0], 5)
        present_pix = (left_x_end+right_x_end)/2
    except:
        present_pix = 128
    return a, present_pix


def region_of_interest(image):
    (height, width) = image.shape
    mask = np.zeros_like(image)
    polygon = np.array([[
        (0, height),
        (0, 180),
        (80, 130),
        (256-80,130),
        (width, 180),   
        (width, height),
    ]], np.int32)

    cv2.fillPoly(mask, polygon, 255)
    masked_image = image * (mask)
 
    return masked_image


def horiz_lines(mask):
    roi = mask[160:180, 96:160]
    try:
        lines = detect_lines(roi)
        lines = lines.reshape(-1,2,2)
        slope = (lines[:,1,1]-lines[:,0,1]) / (lines[:,1,0]-lines[:,0,0])
        
        if (lines[np.where(abs(slope)<0.2)]).shape[0] != 0:
            detected = True
        else:
            detected = False
    except:
        detected = False
    return detected



def detect_side(side_mask):
    side_pix = np.mean(np.where(side_mask[150:190, :]>0), axis=1)[1]
    return side_pix


def reduce_speed(car,breaking):
    car.setSteering(0)
    while car.getSpeed():
        car.setSpeed(breaking)
        car.getData()
    car.setSpeed(0)
    return True

def stop_car(car):
    car.setSteering(0)
    while car.getSpeed():
        car.setSpeed(-150)
        car.getData()
    car.setSpeed(0)
    return True


def turn_the_car(car,s,t):
    time_ref = time.time()
    while((time.time()-time_ref)<t):
        car.getData()
        car.setSteering(s)
        car.setSpeed(60)



def turning_the_car(car,s,t):
    time_ref = time.time()
    while((time.time()-time_ref)<t):
        car.getData()
        car.setSteering(s)
        car.setSpeed(50)

'''
def go_back(car):
    #time_ref = time.time()
    dFront2 = 0
    while(dFront2!=float('inf')):
        car.getData()
        car.setSpeed(-30)
        newImage,dFront,Dleft,Dright,midline_status, mySide, right_points, left_points, right_lines, horizontal_lines, left_lines, dFront2 =linesdetect.white_lines_Distance(car.getImage(), 15, 75, 15)
    print("outttttt")
'''

def go_back(car, t):
    #newImage,dFront,Dleft,Dright,midline_status, mySide, right_points, left_points, right_lines, horizontal_lines, left_lines, dFront2 =linesdetect.white_lines_Distance(imageCopy, 15, 95, 40)
    time_ref = time.time()
    while((time.time()-time_ref)<t):
        car.getData()
        car.setSpeed(-80)
    
def find_intersection(lines,colored_line):
    for line in lines:
        x1, y1, x2, y2 = line[0]
        x3, y3 = colored_line[0][0]
        x4, y4 = colored_line[0][1]

        # Calculate intersection point using line equations
        denominator = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        if denominator == 0:
                continue
        t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denominator
        u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denominator
                
        if 0 <= t <= 1 and 0 <= u <= 1:
                    return True

    return False    

def turn_left(image,car,red_len,pink_len, Dright):
    error = 0
    global red_point,end_crossroad,yellow
    height, width = image.shape[:2]
    car_position = (width // 2, height - 117)
    '''
    print(Dright, "drigh")
    if Dright < 130:
        Dright = 223
    error = Dright-223
    steering_deg = error
'''
    left_lines = []
    right_lines = []
    horizontal_lines = []

    left_lines,right_lines,horizontal_lines = linesdetect.lines_Categorize (image)
    green_line = np.array([[(car_position[0], car_position[1] - 10), (car_position[0], car_position[1] - 90)]], dtype=np.int32)
    blue_line = np.array([[(5 , car_position[1] - 1), (width - 5, car_position[1] - 1)]], dtype=np.int32)
    rect = create_rectangle((300, car_position[1]), (550, car_position[1]), 20, image, (0, 255, 255))
    if(not red_point and find_intersection(right_lines and blue_line)):
         steering_deg = 10
         print("in righting")
    else :
         steering_deg = 0
    # find_intersection between horizontal_lines  and red_line 
    if(not red_point and not end_crossroad):
        red_line = create_rectangle((car_position[0]-3, car_position[1] -130 ), (car_position[0]-3, car_position[1] - red_len), 20, image, (0, 0, 255))
        if(line_intersects_rect(horizontal_lines, red_line)):
            red_point = True
                   
    if(find_intersection(left_lines,green_line)):
          end_crossroad = True
          red_point = False
         
    #end of turn_left and switch operation
    end = False 
    if(end_crossroad):
        if(line_intersects_rect(left_lines + right_lines, rect)):
            yellow = True

        if(yellow) :
             rect_pink = create_rectangle((car_position[0],car_position[1] - 100), (car_position[0]-pink_len,car_position[1] - 100), 20, image, (255, 0, 255))

             if(line_intersects_rect(left_lines ,rect_pink)):
                yellow =  False
                #print('exit$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
                end_crossroad = False
                end = True

    if(red_point or end_crossroad  ):
        steering_deg = -85   
    car.setSteering(steering_deg)    
    return end     
              

def create_thick_line_segment(start, end, thickness):
    dx, dy = end[0] - start[0], end[1] - start[1]
    length = np.hypot(dx, dy)
    if length == 0:
        return None
    # نرمال‌سازی بردار جهت
    nx, ny = -dy / length, dx / length
    # محاسبه جابجایی بر اساس ضخامت
    offset_x, offset_y = nx * (thickness / 2), ny * (thickness / 2)
    
    # چهار نقطه مستطیل
    p1 = (int(start[0] + offset_x), int(start[1] + offset_y))
    p2 = (int(start[0] - offset_x), int(start[1] - offset_y))
    p3 = (int(end[0] - offset_x), int(end[1] - offset_y))
    p4 = (int(end[0] + offset_x), int(end[1] + offset_y))
    
    return np.array([p1, p2, p3, p4], dtype=np.int32)

def line_intersects_rect(lines, rect):
    intersecting_lines = []
    for line in lines:
        x1, y1, x2, y2 = line[0]
        line_coords = ((x1, y1), (x2, y2))
        if single_line_intersects_rect(line_coords, rect):
            intersecting_lines.append(line)
    return intersecting_lines

def single_line_intersects_rect(line, rect):
    x1, y1 = line[0]
    x2, y2 = line[1]
    (xmin, ymin), (xmax, ymax) = rect

    # بررسی اینکه آیا یکی از نقاط خط داخل مستطیل است
    if ((xmin <= x1 <= xmax and ymin <= y1 <= ymax) or
        (xmin <= x2 <= xmax and ymin <= y2 <= ymax)):
        return True

    # تعریف اضلاع مستطیل به صورت خطوط
    rect_lines = [
        ((xmin, ymin), (xmax, ymin)),  # بالا
        ((xmax, ymin), (xmax, ymax)),  # راست
        ((xmax, ymax), (xmin, ymax)),  # پایین
        ((xmin, ymax), (xmin, ymin))   # چپ
    ]

    # بررسی برخورد خط با اضلاع مستطیل
    for edge in rect_lines:
        if line_segments_intersect(line, edge):
            return True

    return False

def line_segments_intersect(line1, line2):
    def ccw(A, B, C):
        return (C[1]-A[1]) * (B[0]-A[0]) > (B[1]-A[1]) * (C[0]-A[0])

    A, B = line1
    C, D = line2

    return (ccw(A, C, D) != ccw(B, C, D)) and (ccw(A, B, C) != ccw(A, B, D))


def create_rectangle(start_point, end_point, thickness, image, color):
                # ایجاد مستطیل ضخیم برای خط زرد
                thick_line = create_thick_line_segment(start_point, end_point, thickness)
                #print(color, "**************************************************************************")
                # رسم مستطیل خط زرد
                if thick_line is not None:
                    cv2.fillPoly(image, [thick_line], color)
                # محاسبه مختصات مستطیل از روی نقاط مستطیل
                xmin = np.min(thick_line[:, 0])
                xmax = np.max(thick_line[:, 0])
                ymin = np.min(thick_line[:, 1])
                ymax = np.max(thick_line[:, 1])
                return ((xmin, ymin), (xmax, ymax))