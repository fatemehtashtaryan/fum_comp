import cv2
import numpy as np

def detect_april_tag(image):
    center_y =0
    center_x = 0
    # تبدیل تصویر به grayscale
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # تعریف دیکشنری AprilTag
    aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_APRILTAG_36h11)
    
    # تشخیص برچسب‌ها
    parameters = cv2.aruco.DetectorParameters()
    detector = cv2.aruco.ArucoDetector(aruco_dict, parameters)
    corners, ids, _ = detector.detectMarkers(gray_image)
    
    # بررسی نتایج
    if ids is not None:
        for i in range(len(ids)):
            myTagId=ids[i][0]
            #2: right / 3: left / 1,4: straight / 5: stop
            if myTagId==1 or myTagId==4:
                myTagDirectionText= "Straight"
            elif myTagId==2: myTagDirectionText="Right"
            elif myTagId==3: myTagDirectionText="Left"
            elif myTagId==5: myTagDirectionText="STOP"

            # print(f"Tag ID: {myTagId}")
            cv2.putText(image, f'Tag ID: {myTagDirectionText}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

            corner_points = corners[i][0]
            center_x = int(np.mean(corner_points[:, 0]))
            center_y = int(np.mean(corner_points[:, 1]))
            # نمایش گوشه‌های برچسب‌ها
            cv2.polylines(image, [np.int32(corners[i])], True, (0, 255, 0), 2)
    else: 
        #cv2.imshow("Image", image)
        return -100 , 0, 0
    center_x ,center_y
    height, width = image.shape[:2]
    car_position = (width // 2, height - 117)
    DistanceApril = int(np.sqrt((center_x - car_position[0]) ** 2 + (center_y - car_position[1]) ** 2))

    return myTagId , DistanceApril, center_x