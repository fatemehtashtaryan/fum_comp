import sys
import os
current = os.path.dirname(os.path.realpath(__file__))# getting the name of the directory where the this file is present.
parent = os.path.dirname(current) # Getting the parent directory name where the current directory is present.
sys.path.append(parent)  # adding the parent directory to the sys.path.
##fastest classic
import avisengine
import config
import time
import cv2
import numpy as np
import control as con
import signs
import csv
import os
import linesdetect
import logging

# Creating an instance of the Car class
car = avisengine.Car()

# Connecting to the server (Simulator)
car.connect(config.SIMULATOR_IP, config.SIMULATOR_PORT)

# Counter variable
           
debug_mode = False
yellow = False
yellow_on = False
global_startLeft = False
global_curveLeft = False
global_curveRight = False
curve_right = False
curve_left = False
detect_april = True
sw_left = False
is_april = False
straight_right = True
near_crossroad = False
end_crossroad= True
cheak_side = False
GettingRightSide = False
GettingLeftSide = False
speed = False

counter = 0  
count = 210
blueLineYDistance = 40
number = 0
save_turn = 0
turn = 0
directionBase=1
afterMistakeCounter=0
MistakeMax= 300
roadStatus=1
turn_right = 1
sw=0
left_counter = 0
Right_counter =0
Right_counter_drive = 0


# Sleep for 3 seconds to make sure that client connected to the simulator 
time.sleep(3)

#to find where we are ! 


start_timer = time.time()
curveStatus = 'No curve'
try:
    '''
    if not os.path.exists("dataset/images"):
       os.makedirs("dataset/images")
    '''
# Open the CSV file once at the start
    '''
    with open("dataset/output.csv", "w", newline='') as csvfile:
       writer = csv.writer(csvfile)
       writer.writerow(["ImageIndex", "angle", "speed"])
    '''
   
    while(True):
        counter = counter + 1


        car.getData()


        if(counter > 4):

            sensors = car.getSensors() 

            # Returns an opencv image type array. if you use PIL you need to invert the color channels.
            image = car.getImage()
            '''
            pnt.imshow(image)
            pnt.show()
            '''
            # Returns an integer which is the real time car speed in KMH
            carSpeed = car.getSpeed()

            if(debug_mode):
                print(f"Speed : {carSpeed}") 
                #print(f'Left : {str(sensors[0])} | Middle : {str(sensors[1])} | Right : {str(sensors[2])}')
            
            imageCopy=image

            dFront,Dleft,Dright, right_lines, horizontal_lines, left_lines,dFront2 =linesdetect.white_lines_Distance(imageCopy, 15, 100, blueLineYDistance)
           
            height, width = imageCopy.shape[:2]
            car_position = (width // 2, height - 117)
            red_line = con.create_rectangle((car_position[0]+10, car_position[1] - 15), (car_position[0]+10, car_position[1] - 145), 13, image, (0, 100, 255))
            if(con.line_intersects_rect(horizontal_lines, red_line)):
                dFront2 = 10
                
            else:
                dFront2 = float('inf')
            apriltagValue = 7
            #car.setSensorAngle(30)
            if(detect_april and counter%10==0 and roadStatus==1):
                apriltagValue, confidence=signs.process_frame(image)
                print(apriltagValue, "is apriil++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++=")
                if(apriltagValue!=7):
                    detect_april =False
            #print(center_x, " center_x^^^^^^")
            #print(position, " is position***********")
            DistanceApril = 300
            if(apriltagValue!=7) : 
                near_crossroad = True
                save_turn = apriltagValue
                is_april = True
                if(car.getSpeed()>=24):
                     speed = True
  
            if (is_april) and (dFront<float('inf') and roadStatus==1 and near_crossroad and not global_curveLeft and not global_curveRight ): 
                print("crosssssssssssssssss")
                roadStatus=2
               
            car.setSensorAngle(30)
            if roadStatus==1: # مسیر عادی
                if(curveStatus == 'No curve'):
                    blueLineYDistance = 77
                    #print("in Status 1")
                    if(not is_april):
                        curveStatus=linesdetect.curve_finder(dFront2, Dleft, Dright)
                        #print("curveStatus+++++++++++++++++++++++++++++++++++++++",curveStatus)
                       
                    #cv2.putText(image, f'Curve Status: {curveStatus}', (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
                    #cv2.putText(image, f'Dfront: {dFront}', (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
                    frame = cv2.resize(image,(256,256))
                    gray_scale = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
                    hsv_frame = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
                    #white_mask = cv2.inRange(frame, np.array([240,240,240]), np.array([255,255,255]))
                    white_mask1 = cv2.inRange(frame, np.array([130,130,130]), np.array([255,255,255]))
                    lines = con.detect_lines(con.region_of_interest(white_mask1))
                    side_line_mask,present_pxl = con.find_lines(white_mask1, lines)
                    side_pixl = con.detect_side(white_mask1)
                    if(not speed):
                        car.setSpeed(40)
                    else:
                        car.setSpeed(32)
                    #print(present_pxl)
                    error = 128- present_pxl
                    steering = -1.2*error
                    if(not GettingLeftSide):car.setSteering(steering)
                    #print(present_pxl, "pisssss")
                    #cv2.imshow("mask ", white_mask1)
                  
                    if(cheak_side and 5<Dright<45):
                           #print("Dright=================================",Dright)
                           GettingLeftSide = True  
                           cheak_side = False     
                    if(GettingLeftSide): 
                        pink_rect = con.create_rectangle((car_position[0],car_position[1] - 100), (car_position[0]-140,car_position[1] - 100), 20, image, (255, 0, 255))
                        if(con.line_intersects_rect(left_lines, pink_rect)):
                            GettingLeftSide = False
                        else :
                             #print("GettingLeftSide")
                             car.setSteering(-70)

                    side_pixl=129
                    if sensors[1] < 790 :
                        print("sensoooorsssssssssssssssssssssssssssssssssssssss",car.getSensors())
                        #con.stop_car(car)
                        #print("############################################it is obstacke######################################################")
                        x = 30
                        if side_pixl > 128:
                            if(car.getSpeed()<10):
                                times = 1.5
                                streeng = -70
                                number = 400
                                print("speed kamtar as 10")
                            elif(car.getSpeed()<15) :
                                print("speed kamtar as 15")
                                times = 1.4
                                streeng = -75
                                number = 400
                            elif(car.getSpeed()<20):
                                print("speed kamtar as 20")
                                times = 1.6
                                streeng = -75
                                number = 500
                            elif(car.getSpeed()<=23 and sensors[1]>=780):
                                print("speed kamtar as 23",car.getSpeed())
                                times = 1.3
                                streeng = -83
                                number = 490

                            elif(car.getSpeed()<=23 and 750<sensors[1]<780):
                                print("speed kamtar as 23",car.getSpeed())
                                times = 1.2
                                streeng = -80
                                number = 490    

                            elif(car.getSpeed()<=23 and sensors[1]<=750):
                                print("speed kamtar as 23",car.getSpeed())
                                times = 1.25
                                streeng = -83
                                number = 490
                            elif(car.getSpeed()==24 and sensors[1]>=770 ) : 
                                print("speed kamtar as 25",car.getSpeed())
                                times = 1.35
                                streeng = -83
                                number = 500
                            elif(car.getSpeed()<=25) : 
                                print("speed kamtar as 25",car.getSpeed())
                                times = 1.4
                                streeng = -83
                                number = 500
                            else :
                                print("speed bishtar as 25",car.getSpeed())
                                times = 1.15
                                streeng = -80
                                number = 460

                            while True:
                                car.getData()
                                x=x+0.13
                                car.setSensorAngle(80)
                                sensors = car.getSensors()
                                car.setSteering(streeng)
                                car.setSpeed(20)
                                if(sensors[2]<number):
                                    detect_april = True
                                    #print("break")
                                    break
                                #print(x, "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
                            #con.turn_the_car(car,-100,2.2)
                            con.turn_the_car(car,100,times)
                            #print("cheakkkkkkkkkkkkkkk")
                            cheak_side = True
                            #con.turn_the_car(car,-100,0.6)
                

                    swich = True
                elif curveStatus == 'Turn right' or global_curveRight :
                    global_curveRight = True
                    GettingLeftSide = False
                    if(global_curveRight) :
                            print("right curve in not stop")
                            car.setSteering(100)
                            car.setSpeed(30)
                            pink_rect = con.create_rectangle((car_position[0],car_position[1] - 100), (car_position[0]+200,car_position[1] - 100), 20, image, (255, 255, 0))
                           # left_lines,right_lines,horizontal_lines = linesdetect.lines_Categorize (image)
                            if(con.line_intersects_rect(right_lines, pink_rect)):
                                global_curveRight = False
                                curveStatus = 'No curve'
                                detect_april = True
                        #con.turning_the_car(car,200,1.8)
                        
                
                elif curveStatus == 'Turn left' or global_curveLeft:
                    global_curveLeft = True
                    GettingLeftSide = False
                    if(global_curveLeft):
                            #print("left curve in not stop")
                            car.setSteering(-100)
                            car.setSpeed(30)
                            pink_rect = con.create_rectangle((car_position[0],car_position[1] - 100), (car_position[0]-200,car_position[1] - 100), 20, image, (255, 0, 255))
                            if(con.line_intersects_rect(left_lines, pink_rect)):
                                global_curveLeft = False
                                curveStatus = 'No curve'
                                detect_april = True
                        #con.turning_the_car(car,-200, 1.8)
                
                #print(isThereMistake)
                #print(curveStatus)

                #myCarControl_1()
            
            if roadStatus==2: # نزدیک چهارراه
                blueLineYDistance = 0
                GettingLeftSide = False
                near_crossroad = False
                is_april = False
                drawing_pink = False
                turn = save_turn
                if(turn==1):
                    blueLineYDistance = 60
                car.setSteering(0)
                command = con.stop_car(car)
                if(turn!=2):
                    time.sleep(3)
                
                roadStatus = 3

                #کم کردن سرعت و توفق به مدت سه ثانیه و بعد از سه ثانیه تبدیل حالت به 3
                #myCarControl_2()
            straight_right=True
            if roadStatus==3: #وسط چهارراه
                if(turn==0): #turn right
                    Steering = 0

                    if(dFront == float('inf') and yellow_on== False) : 
                        yellow = True

                    if(yellow):
                        yellow_on = True
                        rect = con.create_rectangle((-100, car_position[1] +110), (250, car_position[1]+110), 20, image, (0, 255, 255))
                        if con.line_intersects_rect(right_lines, rect):
                            yellow = False

                    if(not yellow and yellow_on ):
                        rect_pink = con.create_rectangle((car_position[0]+170, car_position[1] - 100), (car_position[0], car_position[1] - 100), 20, image, (255, 0, 255))
                        if(con.line_intersects_rect(right_lines, rect_pink)):
                             yellow_on = False
                             turn = 0
                             roadStatus=1
                             detect_april = True
                       
                    if(roadStatus != 1):
                        if(Dright==0):
                            straight_right=False
                        if(straight_right and Dright!=0):
                            if(dFront != float('inf')):car.setSteering(abs(dFront-90))
                            else:car.setSteering(80)
                            car.setSpeed(60)
                        if(Dright==0 and dFront != float('inf')):
                            car.setSpeed(60)
                            car.setSteering(abs(dFront-80))
                    
                elif(turn==3):#turn left
                       #print("in leftttt")
                       maxFrame = 30
                       if((Dleft!=0 or Dright!=0) and not global_startLeft):
                        car.setSpeed(50)
                        left_line = con.create_rectangle((car_position[0]+8, car_position[1] - 15), (car_position[0]+8, car_position[1] - 10), 13, image, (0, 255, 255))
                        if(con.line_intersects_rect(horizontal_lines, left_line)):
                              maxFrame = 29  
                        else :
                              maxFrame = 23  
                       else: 
                        global_startLeft=True
                       if (global_startLeft):
                        car.setSpeed(50)
                        end, steering_deg = con.turn_left(imageCopy,car,144,180, Dright,maxFrame)
                        if(end) :
                            turn = 0
                            global_startLeft=False
                            roadStatus = 1
                            detect_april = True
                        '''
                        count = count+1
                        if not os.path.exists("dataset/images"):
                                os.makedirs("dataset/images")
                        frame = car.getImage()
                            # Open the CSV file once at the start
                            
                            # Save the current frame and the associated data

                        image_path = f"dataset/images/{count}.png"
                        cv2.imwrite(image_path, frame)
                        with open("dataset/output.csv", "a", newline='') as csvfile:
                                writer = csv.writer(csvfile)
                        # Write new data after the file was previously closed
                                writer.writerow([count, steering_deg, car.getSpeed()])
                        '''
                elif(turn==2): #stop
                    break
                elif(turn == 1):#straight:#straight
                        car.setSpeed(100)
                        #print(Dright, " is dright")
                        if Dright < 100 or Dright>200:
                          Dright = 167
                          #print("right is 0")
                        error = Dright-167
                        car.setSteering(1*error)
                        if(dFront == float('inf')):
                            drawing_pink = True
                        if(drawing_pink):
                            height, width = imageCopy.shape[:2]
                            car_position = (width // 2, height - 117)
                            pinkline = np.array([[(car_position[0], car_position[1]-40), (car_position[0]-300, car_position[1] - 40)]], dtype=np.int32)
                            #cv2.polylines(image, pinkline, isClosed=True, color=(255, 0, 255), thickness=2)
                            front_points = []
                           
                            for line in left_lines:
                                x1, y1, x2, y2 = line[0]
                                x3, y3 = pinkline[0][0]
                                x4, y4 = pinkline[0][1]
                                
                                # Calculate intersection point using line equations
                                denominator = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
                                if denominator == 0:
                                  continue
                                t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denominator
                                u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denominator
                                
                                if 0 <= t <= 1 and 0 <= u <= 1:
                                    x = int(x1 + t * (x2 - x1))
                                    y = int(y1 + t * (y2 - y1))
                                    front_points.append(y)
                                    frontx = x
                            if front_points:
                                roadStatus = 1
                                detect_april = True
                   
            # نمایش تصویر
            new_image = cv2.cvtColor(cv2.resize(image,(256,256)),cv2.COLOR_BGR2GRAY)
            main_board = np.hstack((cv2.resize(new_image,(256,256)),white_mask1,side_line_mask,))
            cv2.imshow("main_board",main_board)
            cv2.imshow('Result', image)

            if cv2.waitKey(10) == ord('q'):
                break

            time.sleep(0.001)

finally:
    print(time.time()-start_timer, ": time")
    car.stop()
