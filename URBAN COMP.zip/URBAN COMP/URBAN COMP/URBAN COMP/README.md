# AvisAutoCar
Auto cars Competition for AvisEngine

# installation
pip install -r requirements.txt

or open requirements.txt and install the last versions manually.

Make sure the following files are in the same directory as your program: avisengine.py, utils.py.

You may edit config.py if the IP and port of your Avis engine change.